-- Copyright 2006-2020 Mitchell. See LICENSE.
-- Container LPeg lexer.
-- This is SciTE's plain text lexer.

return require('lexer').new('container')
